#ifndef __JIT_GWORLD_H__
#define __JIT_GWORLD_H__

// nothing to see here

#endif //__JIT_GWORLD_H__
