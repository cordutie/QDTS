#pragma once

#include "c74_max.h"

namespace c74 {
namespace max {

#include "msp-includes/MaxAudioAPI.h"
#include "msp-includes/ext_buffer.h"

}
}
