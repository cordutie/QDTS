#pragma once

#include "c74_max.h"

namespace c74 {
namespace max {

#include "jit-includes/jit.common.h"
#include "jit-includes/max.jit.mop.h"

}
}
