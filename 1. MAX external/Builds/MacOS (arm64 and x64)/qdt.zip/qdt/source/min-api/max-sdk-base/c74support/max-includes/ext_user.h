#ifndef __EXT_USER
#define __EXT_USER

// 	NOTE: This file is obsolete.

#endif

