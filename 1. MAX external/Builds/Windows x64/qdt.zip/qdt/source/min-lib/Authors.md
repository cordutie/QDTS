# Authors
Names should be added to this file with this pattern:

For individuals:
   `Name <email address>`

For organizations:
   `Organization <fnmatch pattern>`



```
Cycling '74 <*@cycling74.com>
Nathan Wolek <nw@nathanwolek.com>
Trond Lossius <trond@trondlossius.no>
```





