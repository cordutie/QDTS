// dummy to prevent compiler warnings

template <typename T>
void dummy(){}

template void dummy<int>();