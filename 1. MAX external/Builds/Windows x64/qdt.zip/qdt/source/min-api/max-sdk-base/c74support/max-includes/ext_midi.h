#ifndef _EXT_MIDI_H_
#define _EXT_MIDI_H_

// 	NOTE: This file is obsolete.

#endif /* _EXT_MIDI_H_ */
